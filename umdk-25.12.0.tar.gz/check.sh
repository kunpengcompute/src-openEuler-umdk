#!/bin/bash

if [ $# -ne 1 ]; then
    echo "使用方法: $0 <文件夹路径>"
    exit 1
fi

directory="$1"

if [ ! -d "$directory" ]; then
    echo "错误: 文件夹 '$directory' 不存在"
    exit 1
fi

echo "统计文件夹: $directory 的所有文件"
echo "=========================================="

# 使用find和wc统计所有文件
result=$(find "$directory" -type f -exec wc -l {} + 2>/dev/null | tail -1)

if [ -n "$result" ]; then
    echo "总行数: $result"
else
    echo "没有找到文件或无法读取"
fi

# 显示文件数量
file_count=$(find "$directory" -type f | wc -l)
echo "文件总数: $file_count"
