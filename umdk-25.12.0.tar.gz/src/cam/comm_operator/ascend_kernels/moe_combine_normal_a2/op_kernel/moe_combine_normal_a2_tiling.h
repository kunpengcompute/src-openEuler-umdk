/*
 * SPDX-License-Identifier: MIT
 * Copyright (c) Huawei Technologies Co., Ltd. 2026-2026. All rights reserved.
 * Description: combine normal A2 kernel part tiling
 * Create: 2026-01-15
 * Note:
 * History: 2026-01-15 create combine normal A2 kernel part tiling
 */

#ifndef MOE_COMBINE_NORMAL_A2_TILING_H
#define MOE_COMBINE_NORMAL_A2_TILING_H

#include <cstdint>
#include "kernel_tiling/kernel_tiling.h"

namespace Moe {
struct MoeCombineNormalA2Info {
    uint32_t epWorldSize;          // epWorldSize
    uint32_t tpWorldSize;          // tpWorldSize
    uint32_t epRankId;             // epRankId
    uint32_t tpRankId;             // tpRankId
    uint32_t expertSharedType;     // expert type
    uint32_t sharedExpertRankNum;  // shared expert number
    uint32_t moeExpertNum;         // moe expert number
    uint32_t globalBs;             // globalBs = BS * worldSize
    uint32_t bs;                   // bs
    uint32_t k;                    // k
    uint32_t h;                    // h
    uint32_t aivNum;               // aivNum
    uint64_t totalUbSize;          // epWorldSize
    uint32_t hcclBufferSize;       // HCCL windows, unit:B
    uint32_t rsd;
};

struct MoeCombineNormalA2TilingData {
    Mc2InitTiling mc2InitTiling;
    Mc2CcTiling mc2CcTiling;
    MoeCombineNormalA2Info moeCombineNormalInfo;
};
} // namespace Moe
#endif  //__MOE_COMBINE_NORMAL_A2_TILING_H__
