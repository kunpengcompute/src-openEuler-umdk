/*
 * SPDX-License-Identifier: MIT
 * Copyright (c) Huawei Technologies Co., Ltd. 2023-2025. All rights reserved.
 * Description: urma_admin log implementation
 * Author: Qian Guoxin
 * Create: 2023-2-16
 * Note:
 * History: 2023-2-16 inital implementation of urma_admin log
 */

#include <stdarg.h>
#include <stdio.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/syscall.h>

#include "admin_log.h"

#define MAX_LOG_LEN                1024
#define URMA_LOG_TAG               "URMA"
#define ADMIN_LOG_TAG              "urma_admin"
#define URMA_ADMIN_VLOG_LEVEL_INFO 6

static int urma_admin_vlog(const char *file, const char *function, int line,
    const char *format, va_list va)
{
    int ret;
    char newformat[MAX_LOG_LEN + 1] = {0};
    char logmsg[MAX_LOG_LEN + 1] = {0};

    /* add log head info, "[URMA][urma_admin][thread_id=tid][-][file:function:line]format" */
    ret = snprintf(newformat, MAX_LOG_LEN, "[%s][%s][thread_id=%ld][-][%s:%s:%d]%s",
        URMA_LOG_TAG, ADMIN_LOG_TAG, (long)syscall(__NR_gettid), file, function, line, format);
    if (ret <= 0 || ret >= (int)sizeof(newformat)) {
        return ret;
    }
    ret = vsnprintf(logmsg, MAX_LOG_LEN, newformat, va);
    if (ret == -1) {
        (void)printf("logmsg size exceeds MAX_LOG_LEN size : %d\n", MAX_LOG_LEN);
        return ret;
    }
    syslog(URMA_ADMIN_VLOG_LEVEL_INFO, "%s", logmsg);

    return ret;
}

void urma_admin_log(const char *file, const char *function, int line, const char *format, ...)
{
    va_list va;

    va_start(va, format);
    (void)urma_admin_vlog(file, function, line, format, va);
    va_end(va);
}
