/*
 * SPDX-License-Identifier: MIT
 * Copyright (c) Huawei Technologies Co., Ltd. 2023-2025. All rights reserved.
 * Description: parse parameters for urma_admin
 * Author: Qian Guoxin
 * Create: 2023-01-04
 * Note:
 * History: 2023-01-04   create file
 */

#include <arpa/inet.h>
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "ub_util.h"

#include "admin_file_ops.h"
#include "admin_log.h"

#include "admin_parameters.h"

static bool check_dev_name(char *dev_name)
{
    bool ret = false;
    DIR *cdev_dir;
    struct dirent *dent;

    cdev_dir = opendir(CDEV_PATH);
    if (cdev_dir == NULL) {
        (void)printf("%s open failed, errno: %d.\n", CDEV_PATH, errno);
        return false;
    }

    while ((dent = readdir(cdev_dir)) != NULL) {
        if (strcmp(dent->d_name, dev_name) == 0) {
            ret = true;
            break;
        }
    }

    if (closedir(cdev_dir) < 0) {
        (void)printf("Failed to close dir: %s, errno: %d.\n", CDEV_PATH, errno);
    }
    return ret;
}

int admin_parse_dev_name(char *buf, admin_config_t *cfg)
{
    if (strnlen(buf, URMA_ADMIN_MAX_DEV_NAME) + 1 > URMA_ADMIN_MAX_DEV_NAME || check_dev_name(buf) == false) {
        (void)printf("dev_name:%s out of range(%d) or invalid.\n", buf, URMA_ADMIN_MAX_DEV_NAME);
        URMA_ADMIN_LOG("dev_name:%s out of range(%d) or invalid.\n", buf, URMA_ADMIN_MAX_DEV_NAME);
        return -1;
    }
    cfg->specify_device = true;
    (void)memcpy(cfg->dev_name, buf, strlen(buf));
    return 0;
}

int admin_parse_ns(char *buf, admin_config_t *cfg)
{
    if (strnlen(buf, URMA_ADMIN_MAX_NS_PATH) + 1 > URMA_ADMIN_MAX_NS_PATH) {
        (void)printf("ns path:%s out of range(%d) or invalid.\n", buf, URMA_ADMIN_MAX_NS_PATH);
        URMA_ADMIN_LOG("ns path:%s out of range(%d) or invalid.\n", buf, URMA_ADMIN_MAX_NS_PATH);
        return -1;
    }
    if (snprintf(cfg->ns, URMA_ADMIN_MAX_NS_PATH, "%s", buf) <= 0) {
        URMA_ADMIN_LOG("Failed to prepare buf.\n");
        return -1;
    }
    return 0;
}

static int admin_parse_sharing(char *buf, admin_config_t *cfg)
{
    if (buf == NULL) {
        (void)printf("Invalid argument.\n");
        return -EINVAL;
    }

    // 先复用ns_mode
    if (strcmp(buf, "on") == 0) {
        cfg->sharing_on = true;
    } else if (strcmp(buf, "off") == 0) {
        cfg->sharing_on = false;
    } else {
        URMA_ADMIN_LOG("Invalid sharing mode:%s, expect 'on' or 'off'.\n", buf);
        return -1;
    }
    return 0;
}

char *pop_arg(admin_config_t *cfg)
{
    if (cfg->argc <= 0) {
        return NULL;
    }

    char *arg = *cfg->argv;
    cfg->argc--;
    cfg->argv++;

    return arg;
}

int pop_arg_dev(admin_config_t *cfg)
{
    char *arg = pop_arg(cfg);
    if (arg == NULL) {
        printf("No device name specified.\n");
        return -EINVAL;
    }
    return admin_parse_dev_name(arg, cfg);
}

int pop_arg_ns(admin_config_t *cfg)
{
    char *arg = pop_arg(cfg);
    if (arg == NULL) {
        printf("No namespace specified.\n");
        return -EINVAL;
    }
    int ret = admin_parse_ns(arg, cfg);
    return ret;
}

int pop_arg_sharing(admin_config_t *cfg)
{
    char *arg = pop_arg(cfg);
    if (arg == NULL) {
        printf("No sharing mode specified.\n");
        return -EINVAL;
    }
    int ret = admin_parse_sharing(arg, cfg);
    return ret;
}

int pop_arg_eid(admin_config_t *cfg)
{
    char *arg = pop_arg(cfg);
    int ret = urma_str_to_eid(arg, &cfg->eid);
    if (ret != 0) {
        printf("No eid specified.\n");
        return -EINVAL;
    }
    return ret;
}

int pop_arg_eid_idx(admin_config_t *cfg)
{
    char *arg = pop_arg(cfg);
    int ret = ub_str_to_u16(arg, &cfg->idx);
    if (ret != 0) {
        printf("No eid idx specified.\n");
        return -EINVAL;
    }
    return ret;
}

int pop_arg_eid_mode(admin_config_t *cfg)
{
    char *arg = pop_arg(cfg);
    if (arg == NULL) {
        printf("No eid mode specified.\n");
        return -EINVAL;
    }

    const char *eid_mode_static = "static";
    const char *eid_mode_dynamic = "dynamic";

    if (strncmp(arg, eid_mode_static, strlen(eid_mode_static) + 1) == 0) {
        cfg->dynamic_eid_mode = false;
    } else if (strncmp(arg, eid_mode_dynamic, strlen(eid_mode_dynamic) + 1) == 0) {
        cfg->dynamic_eid_mode = true;
    } else {
        printf("Invalid eid mode:%s, expect 'dynamic' or 'static'.\n", arg);
        return -EINVAL;
    }

    return 0;
}

#define ADMIN_NET_NS_PATH_MAX_LEN  256
/* Path1 format: /var/run/netns/$ns_name */
#define ADMIN_NET_NS_PATH1_PREFIX  "/var/run/netns/"
#define ADMIN_NET_NS_PATH1_MIN_LEN strlen(ADMIN_NET_NS_PATH1_PREFIX)
/* Path2 format: /proc/$pid/ns/net */
#define ADMIN_NET_NS_PATH2_PREFIX  "/proc/"
#define ADMIN_NET_NS_PATH2_SUFFIX  "/ns/net"
/* The minimum length of path2: $pid occupies at least 1 character */
#define ADMIN_NET_NS_PATH2_MIN_LEN 14

/**
 * @brief 检查字符串是否为非空纯数字串（仅包含 '0'-'9'）
 * @param s 输入字符串
 * @return 1 表示是纯数字，0 表示不是或为空
 */
static bool is_numeric_string(const char *s)
{
    if (!s || *s == '\0') {
        return false;
    }
    for (const char *p = s; *p != '\0'; ++p) {
        if (!isdigit((unsigned char)*p)) {
            return false;
        }
    }
    return true;
}

static bool urma_validate_ns_path(const char *path)
{
    /* ns path is a special symbolic link, cannot be checked by realpath */
    /* check path format1: /var/run/netns/$ns_name->/proc/$pid/ns/net */
    size_t path_len = strnlen(path, ADMIN_NET_NS_PATH_MAX_LEN);
    if (path_len > ADMIN_NET_NS_PATH1_MIN_LEN && path_len < ADMIN_NET_NS_PATH_MAX_LEN &&
        (strncmp(path, ADMIN_NET_NS_PATH1_PREFIX, ADMIN_NET_NS_PATH1_MIN_LEN) == 0)) {
        /* check if there is still "/./" or "/../" after "ns/"-> check if there is any sub_str can be
           splitted by "/" */
        char ns_name[ADMIN_NET_NS_PATH_MAX_LEN + 1] = {0};
        /* check ns_name not containing "/" */
        int ret = sscanf(path + ADMIN_NET_NS_PATH1_MIN_LEN, "%[^/]", ns_name);
        if (ret < 0 || strlen(ns_name) + ADMIN_NET_NS_PATH1_MIN_LEN != path_len) {
            (void)printf("path 1 is invalid, ns_name: %s, ret: %d, errno: %d.\n", ns_name, ret, errno);
            return false;
        }
        return true;
    }

    /* check path format2: /proc/$pid/ns/net */
    if (path_len < ADMIN_NET_NS_PATH2_MIN_LEN || path_len >= ADMIN_NET_NS_PATH_MAX_LEN) {
        (void)printf("The len of ns realpath:%s is invalid, len: %lu.\n", path, path_len);
        return false;
    }

    /* /proc/ */
    size_t sub_str_len = strlen(ADMIN_NET_NS_PATH2_PREFIX);
    uint64_t offset = sub_str_len;
    if (offset >= path_len || strncmp(path, ADMIN_NET_NS_PATH2_PREFIX, sub_str_len) != 0) {
        (void)printf("path 2 is invalid, should start with '/proc/', path: %s.\n", path);
        return false;
    }

    /* pid */
    char num_str[ADMIN_NET_NS_PATH_MAX_LEN + 1] = {0};
    /* check sub_str only containing number */
    int success_len = sscanf(path + offset, "%[0-9]", num_str);
    /* The return value of sscanf_s is the number of string successfully matched */
    if (success_len != 1) {
        (void)printf("failed to get pid.\n");
        return false;
    }
    sub_str_len = strnlen(num_str, ADMIN_NET_NS_PATH_MAX_LEN);
    offset += sub_str_len;

    /* /ns/net */
    if (strcmp(path + offset, ADMIN_NET_NS_PATH2_SUFFIX) != 0) {
        (void)printf("path is not valid: should be /proc/pid/ns/net.\n");
        return false;
    }
    return true;
}

int admin_get_ns_fd(const char *ns)
{
    int ns_fd;
    char path[ADMIN_NET_NS_PATH_MAX_LEN];
    if (is_numeric_string(ns)) {
        snprintf(path, sizeof(path), "/proc/%s/ns/net", ns);
    } else {
        snprintf(path, sizeof(path), "%s", ns);
    }
    /* validate input */
    if (urma_validate_ns_path(path) == false) {
        (void)printf("ns path is invalid: %s.\n", path);
        return -EINVAL;
    }

    ns_fd = open(path, O_RDONLY | O_CLOEXEC);
    if (ns_fd == -1) {
        (void)printf("failed to open ns file %s, errno:%d\n", path, errno);
        return ns_fd;
    }
    return ns_fd;
}
