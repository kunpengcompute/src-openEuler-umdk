/*
 * SPDX-License-Identifier: MIT
 * Copyright (c) Huawei Technologies Co., Ltd. 2026-2026. All rights reserved.
 * Description: Bond provider datapath convert header file
 * Author: Wang Hang
 * Create: 2026-04-02
 * Note:
 * History: 2026-04-02   Create File
 */

#ifndef BONDP_DATAPATH_CONVERT_H
#define BONDP_DATAPATH_CONVERT_H

#include <stdint.h>

#include "bondp_connection.h"

#ifdef __cplusplus
extern "C" {
#endif

static inline bool is_rw_wr(const urma_jfs_wr_t *wr)
{
    return wr->opcode == URMA_OPC_WRITE || wr->opcode == URMA_OPC_WRITE_IMM ||
           wr->opcode == URMA_OPC_WRITE_NOTIFY || wr->opcode == URMA_OPC_READ;
}
static inline bool is_send_wr(const urma_jfs_wr_t *wr)
{
    return wr->opcode == URMA_OPC_SEND || wr->opcode == URMA_OPC_SEND_IMM ||
           wr->opcode == URMA_OPC_SEND_INVALIDATE;
}
static inline bool is_atomic_wr(const urma_jfs_wr_t *wr)
{
    return wr->opcode == URMA_OPC_CAS || wr->opcode == URMA_OPC_FADD;
}

urma_status_t copy_jfs_wr(const urma_jfs_wr_t *src, urma_jfs_wr_t *dst,
                          urma_sge_t *prealloc_src_sge, urma_sge_t *prealloc_dst_sge,
                          uint32_t max_sge, uint32_t max_rsge);
urma_status_t copy_jfr_wr(const urma_jfr_wr_t *src, urma_jfr_wr_t *dst,
                          urma_sge_t *prealloc_src_sge, uint32_t max_sge);

void free_jfr_wr(urma_jfr_wr_t *wr);
void free_jfs_wr(urma_jfs_wr_t *wr);

void encode_jfs_wr_msn(urma_jfs_wr_t *wr, bondp_comp_t *bdp_comp, uint32_t msn, bool enable_msn);

urma_status_t check_jfs_wr_path(urma_jfs_wr_t *wr, int send_idx, int target_idx);

void convert_jfs_vwr_to_pwr(urma_jfs_wr_t *wr, int send_idx, int target_idx);
void convert_jfs_pwr_to_vwr(urma_jfs_wr_t *wr, urma_target_jetty_t *vtjetty);

void convert_jfr_vwr_to_pwr(urma_jfr_wr_t *wr, int recv_idx);
void convert_pcr_to_vcr(urma_cr_t *cr, bondp_context_t *bdp_ctx, uint32_t *msn);

static inline bool is_recv_cr(const urma_cr_t *cr)
{
    return cr->flag.bs.s_r == 1;
}

/*
 * When the cr status is URMA_CR_WR_SUSPEND_DONE or URMA_CR_WR_FLUSH_ERR_DONE,
 * it indicates that the CR is a fake one constructed by hardware.
 * At this time, the `urma_ctx` field in CR is invalid and most likely 0.
 */
static inline bool is_fake_cr(const urma_cr_t *cr)
{
    return cr->status == URMA_CR_WR_SUSPEND_DONE ||
           cr->status == URMA_CR_WR_FLUSH_ERR_DONE;
}

/*
 * We currently consider the following status codes on the sender side
 * as indicators of a fault that should recover.
 */
static inline bool is_failover_cr(const urma_cr_t *cr)
{
    return cr->status == URMA_CR_LOC_LEN_ERR ||
           cr->status == URMA_CR_LOC_ACCESS_ERR ||
           cr->status == URMA_CR_ACK_TIMEOUT_ERR;
}

#ifdef __cplusplus
}
#endif

#endif // BONDP_DATAPATH_CONVERT_H
