/*
 * SPDX-License-Identifier: MIT
 * Copyright (c) Huawei Technologies Co., Ltd. 2023-2025. All rights reserved.
 * Description: tpsa api file
 * Author: Zheng Hongqin
 * Create: 2023-11-22
 * Note:
 * History:
 */

#include "tpsa_ioctl.h"
#include "tpsa_topo_helper.h"
#include "uvs_api.h"
#include "uvs_cmd_tlv.h"
#include "uvs_private_api.h"
#include "uvs_ubagg_ioctl.h"
#include <errno.h>
#include <string.h>
#include <sys/syscall.h>

static inline bool uvs_eid_is_valid(const uvs_eid_t *eid)
{
    return !(eid->in6.interface_id == 0 && eid->in6.subnet_prefix == 0);
}

int uvs_create_agg_dev(uvs_eid_t *agg_eid, const char *dev_name)
{
    int ret = 0;
    size_t dev_name_len;

    if (agg_eid == NULL || dev_name == NULL) {
        TPSA_LOG_ERR("Invalid parameter.\n");
        return -EINVAL;
    }

    dev_name_len = strnlen(dev_name, UVS_MAX_DEV_NAME_LEN);
    if (dev_name_len == 0 || dev_name_len >= UVS_MAX_DEV_NAME_LEN) {
        TPSA_LOG_ERR("Invalid parameter.\n");
        return -EINVAL;
    }

    ret = uvs_ubagg_ioctl_create_agg_dev(agg_eid, dev_name);
    if (ret != 0) {
        TPSA_LOG_ERR("failed to create agg dev in ubagg, ret = %d.\n", ret);
        return ret;
    }

    return ret;
}

int uvs_delete_agg_dev(uvs_eid_t *agg_eid)
{
    int ret = 0;

    if (agg_eid == NULL) {
        TPSA_LOG_ERR("Invalid parameter.\n");
        return -EINVAL;
    }

    ret = uvs_ubagg_ioctl_delete_agg_dev(agg_eid);
    if (ret != 0) {
        TPSA_LOG_ERR("failed to delete agg dev in ubagg, ret = %d.\n", ret);
        return ret;
    }

    return ret;
}

int uvs_get_device_name_by_eid(uvs_eid_t *eid, char *buf, size_t len)
{
    int ret = 0;

    if (buf == NULL || len == 0 || len > UVS_MAX_DEV_NAME_LEN || eid == NULL) {
        TPSA_LOG_ERR("Invalid parameter.\n");
        return -EINVAL;
    }

    ret = uvs_ubagg_ioctl_get_dev_name_by_eid(eid, buf, len);
    if (ret != 0) {
        TPSA_LOG_ERR("failed to get dev name by eid in ubagg, ret = %d.\n", ret);
        return ret;
    }

    return 0;
}

int uvs_insert_main_ue_eid(const uvs_main_ue_eid_entry_t *entry)
{
    int ret;

    if (entry == NULL) {
        TPSA_LOG_ERR("Invalid main ue eid entry.\n");
        return -EINVAL;
    }

    uvs_get_api_rdlock();
    ret = uvs_ubcore_ioctl_insert_main_ue_eid(entry);
    put_uvs_lock();
    return ret;
}

int uvs_insert_main_ue_eid_batch(const uvs_main_ue_eid_batch_entry_t *entry)
{
    if (entry == NULL || entry->eid_num == 0 ||
        entry->eid_num > UVS_MAIN_UE_EID_BATCH_EID_MAX) {
        TPSA_LOG_ERR("Invalid main ue eid batch entry.\n");
        return -EINVAL;
    }

    TPSA_LOG_ERR("insert main ue eid batch is not supported.\n");
    return -EOPNOTSUPP;
}

int uvs_delete_main_ue_eid(const uvs_eid_t *eid)
{
    int ret;

    if (eid == NULL) {
        TPSA_LOG_ERR("Invalid main ue eid.\n");
        return -EINVAL;
    }

    uvs_get_api_rdlock();
    ret = uvs_ubcore_ioctl_delete_main_ue_eid(eid);
    put_uvs_lock();
    return ret;
}

int uvs_lookup_main_ue_eid(const uvs_eid_t *eid, uvs_eid_t *main_ue_eid)
{
    int ret;

    if (eid == NULL || main_ue_eid == NULL) {
        TPSA_LOG_ERR("Invalid main ue eid lookup param.\n");
        return -EINVAL;
    }

    uvs_get_api_rdlock();
    ret = uvs_ubcore_ioctl_lookup_main_ue_eid(eid, main_ue_eid);
    put_uvs_lock();
    return ret;
}

int uvs_flush_main_ue_eid(void)
{
    int ret;

    uvs_get_api_rdlock();
    ret = uvs_ubcore_ioctl_flush_main_ue_eid();
    put_uvs_lock();
    return ret;
}

static int uvs_set_topo_info_inner(struct urma_topo_node *topo, uint32_t topo_num)
{
    int ret;

    if (!topo || topo_num > MAX_NODE_NUM || topo_num == 0) {
        TPSA_LOG_ERR("topo is NULL or topo_num is invalid.\n");
        return -EINVAL;
    }

    ret = uvs_ubagg_ioctl_set_topo(topo, (int)topo_num);
    if (ret != 0) {
        TPSA_LOG_ERR("failed to set topo info in ubagg, ret = %d.\n", ret);
        return ret;
    } else {
        TPSA_LOG_INFO("successfully setted topo info in ubagg\n");
    }

    ret = uvs_update_main_ue_eid_table_by_topo(topo, topo_num);
    if (ret != 0) {
        TPSA_LOG_ERR("failed to update main ue eid table by topo, ret = %d.\n", ret);
        return ret;
    }

    ret = uvs_ubcore_ioctl_set_topo(topo, (int)topo_num);
    if (ret != 0) {
        TPSA_LOG_ERR("failed to set topo info in ubcore, ret = %d.\n", ret);
        return ret;
    } else {
        TPSA_LOG_INFO("successfully setted topo info in ubcore\n");
    }

    return ret;
}

static int uvs_set_share_topo_info_inner(struct urma_topo_node *topo, uint32_t topo_num)
{
    int ret;

    if (!topo || topo_num > MAX_NODE_NUM || topo_num == 0) {
        TPSA_LOG_ERR("share topo is NULL or topo_num is invalid.\n");
        return -EINVAL;
    }

    ret = uvs_update_host_eid_table_by_share_topo(topo, topo_num);
    if (ret != 0) {
        TPSA_LOG_ERR("failed to update host eid table by share topo, ret = %d.\n", ret);
        return ret;
    }

    TPSA_LOG_INFO("successfully updated host eid table by share topo\n");
    return 0;
}

static int uvs_get_topo_info_inner(void *topo)
{
    int ret;

    if (!topo) {
        TPSA_LOG_ERR("topo is NULL.\n");
        return -EINVAL;
    }

    ret = uvs_ubagg_ioctl_get_topo_info((uvs_ubagg_topo_info_out_t *)topo);
    if (ret != 0) {
        TPSA_LOG_ERR("failed to get topo info in ubagg.\n");
        return ret;
    } else {
        TPSA_LOG_INFO("successfully got topo info in ubagg\n");
    }

    return ret;
}

int uvs_set_topo_info(void *topo_buf, uint32_t node_size, uint32_t node_num)
{
    uint32_t size = sizeof(struct urma_topo_node);
    int ret;

    if (size != node_size) {
        TPSA_LOG_ERR("node size not match, urma=%u, ubse=%u\n", size, node_size);
        return -EINVAL;
    }

    uvs_get_api_rdlock();
    ret = uvs_set_topo_info_inner(topo_buf, node_num);
    put_uvs_lock();
    return ret;
}

int uvs_set_share_topo_info(void *topo_buf, uint32_t node_size, uint32_t node_num)
{
    uint32_t size = sizeof(struct urma_topo_node);
    int ret;

    if (size != node_size) {
        TPSA_LOG_ERR("node size not match, urma=%u, ubse=%u\n", size, node_size);
        return -EINVAL;
    }

    uvs_get_api_rdlock();
    ret = uvs_set_share_topo_info_inner(topo_buf, node_num);
    put_uvs_lock();
    return ret;
}

int uvs_get_topo_info(void *topo)
{
    int ret = 0;
    uvs_get_api_rdlock();
    ret = uvs_get_topo_info_inner(topo);
    put_uvs_lock();
    return ret;
}

int uvs_get_path_set(const uvs_eid_t *src_bonding_eid,
                     const uvs_eid_t *dst_bonding_eid,
                     enum uvs_tp_type tp_type, bool iodie_level,
                     uvs_path_set_t *uvs_path_set)
{
    int ret = 0;

    if (src_bonding_eid == NULL || dst_bonding_eid == NULL) {
        TPSA_LOG_ERR("Invalid parameter.\n");
        return -EINVAL;
    }

    if (tp_type > UVS_UTP || tp_type < UVS_RTP) {
        TPSA_LOG_ERR("Invalid tp_type.\n");
        return -EINVAL;
    }

    if (!uvs_eid_is_valid(src_bonding_eid) ||
        !uvs_eid_is_valid(dst_bonding_eid) ||
        uvs_path_set == NULL) {
        TPSA_LOG_ERR("Invalid parameter.\n");
        return -EINVAL;
    }
    ret = uvs_ubcore_ioctl_get_path_set(src_bonding_eid,
                                        dst_bonding_eid, tp_type, iodie_level, uvs_path_set);
    if (ret != 0) {
        TPSA_LOG_ERR("Failed to get path set, ret = %d.\n", ret);
        return ret;
    }

    return ret;
}
