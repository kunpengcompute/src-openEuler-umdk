// SPDX-License-Identifier: MIT
/*
 * Copyright (c) 2025 HiSilicon Technologies Co., Ltd. All rights reserved.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
 * MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 *
 */

#include <string.h>
#include "udma_u_common.h"
#include "udma_u_ctrlq_tp.h"

int udma_u_ctrlq_get_tp_list(urma_context_t *ctx, urma_get_tp_cfg_t *cfg, uint32_t *tp_cnt,
			     urma_tp_info_t *tp_list)
{
	urma_cmd_udrv_priv_t udata = {};
	int ret;

	ret = urma_cmd_get_tp_list(ctx, cfg, tp_cnt, tp_list, &udata);
	if (ret)
		UDMA_LOG_ERR("URMA get TP list failed, ret = %d.\n", ret);

	return ret;
}

int udma_u_ctrlq_set_tp_attr(const urma_context_t *ctx, const uint64_t tp_handle,
			     const uint8_t tp_attr_cnt, const uint32_t tp_attr_bitmap,
			     const urma_tp_attr_value_t *tp_attr)
{
	int ret;

	ret = urma_cmd_set_tp_attr(ctx, tp_handle, tp_attr_cnt, tp_attr_bitmap, tp_attr, NULL);
	if (ret)
		UDMA_LOG_ERR("URMA command set TP attributes failed, ret = %d.\n", ret);

	return ret;
}

int udma_u_ctrlq_get_tp_attr(const urma_context_t *ctx, const uint64_t tp_handle,
			     uint8_t *tp_attr_cnt, uint32_t *tp_attr_bitmap,
			     urma_tp_attr_value_t *tp_attr)
{
	int ret;

	ret = urma_cmd_get_tp_attr(ctx, tp_handle, tp_attr_cnt, tp_attr_bitmap, tp_attr, NULL);
	if (ret)
		UDMA_LOG_ERR("URMA command get TP attributes failed, ret = %d.\n", ret);

	return ret;
}

urma_status_t udma_u_get_smac(const urma_context_t *ctx, uint8_t *mac)
{
	urma_status_t ret;

	ret = urma_cmd_get_smac(ctx, mac);
	if (ret)
		UDMA_LOG_ERR("URMA command get smac failed, ret = %d.\n", ret);

	return ret;
}

urma_status_t udma_u_get_dmac(const urma_context_t *ctx, const urma_net_addr_t *net_addr, uint8_t *mac)
{
	urma_status_t ret;

	ret = urma_cmd_get_dmac(ctx, net_addr, mac);
	if (ret)
		UDMA_LOG_ERR("URMA command get dmac failed, ret = %d.\n", ret);

	return ret;
}

urma_status_t udma_u_get_eid_by_ip(const urma_context_t *ctx, const urma_net_addr_t *net_addr, urma_eid_t *eid)
{
	urma_status_t ret;

	ret = urma_cmd_get_eid_by_ip(ctx, net_addr, eid);
	if (ret)
		UDMA_LOG_ERR("URMA command get EID by IP failed, ret = %d.\n", ret);

	return ret;
}

urma_status_t udma_u_get_ip_by_eid(const urma_context_t *ctx, const urma_eid_t *eid, urma_net_addr_t *net_addr)
{
	urma_status_t ret;

	ret = urma_cmd_get_ip_by_eid(ctx, eid, net_addr);
	if (ret)
		UDMA_LOG_ERR("URMA command get IP by EID failed, ret = %d.\n", ret);

	return ret;
}