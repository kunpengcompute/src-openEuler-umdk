// SPDX-License-Identifier: MIT
/*
 * Copyright (c) 2025 HiSilicon Technologies Co., Ltd. All rights reserved.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
 * MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 *
 */

#include <errno.h>
#include "urma_private.h"
#include "udma_u_buf.h"
#include "udma_u_db.h"
#include "udma_u_jfc.h"
#include "udma_u_jfr.h"

int udma_u_verify_jfr_param(urma_context_t *ctx, urma_jfr_cfg_t *cfg)
{
	urma_device_cap_t *cap = &ctx->dev->sysfs_dev->dev_attr.dev_cap;

	if (!cfg->max_sge || !cfg->depth ||
		roundup_pow_of_two(cfg->depth) > cap->max_jfr_depth ||
	    roundup_pow_of_two(cfg->max_sge) > cap->max_jfr_sge) {
		UDMA_LOG_ERR("invalid JFR parameter, depth = %u, max_SGE = %u.\n",
			     cfg->depth, cfg->max_sge);
		return EINVAL;
	}

	if (cfg->flag.bs.token_policy > URMA_TOKEN_PLAIN_TEXT) {
		UDMA_LOG_ERR("jfr token policy = %d is not supported now.\n",
			     cfg->flag.bs.token_policy);
		return EINVAL;
	}

	return 0;
}

void udma_u_init_jfr_param(struct udma_u_jfr *jfr, urma_jfr_cfg_t *cfg)
{
	if (cfg->depth < UDMA_U_MIN_JFR_DEPTH)
		jfr->wqe_cnt = UDMA_U_MIN_JFR_DEPTH;
	else
		jfr->wqe_cnt = roundup_pow_of_two(cfg->depth);

	jfr->max_sge = roundup_pow_of_two(cfg->max_sge);
	jfr->rq.trans_mode  = cfg->trans_mode;
	jfr->wqe_shift = UDMA_U_ILOG32(roundup_pow_of_two(UDMA_SGE_SIZE *
							  jfr->max_sge));
	jfr->lock_free = cfg->flag.bs.lock_free;
	jfr->rq.pi = 0;
	jfr->rq.ci = 0;
}

static int udma_u_create_rq(struct udma_u_context *udma_ctx,
			    struct udma_u_jfr *jfr)
{
	struct udma_u_jetty_queue *rq = &jfr->rq;
	uint32_t sge_per_wqe;
	uint32_t wqebb_cnt;

	sge_per_wqe = UDMA_MIN(jfr->max_sge, udma_ctx->jfr_sge);
	wqebb_cnt = sge_per_wqe * jfr->wqe_cnt;

	if (!udma_u_alloc_queue_buf(rq, wqebb_cnt, UDMA_JFR_WQEBB,
				   UDMA_HW_PAGE_SIZE, true)) {
		UDMA_LOG_ERR("failed to alloc JFR work queue entry buffer.\n");
		return EINVAL;
	}

	return 0;
}

int exec_jfr_create_cmd(urma_context_t *ctx, struct udma_u_jfr *jfr,
			urma_jfr_cfg_t *cfg)
{
	struct udma_create_jetty_ucmd cmd = {};
	struct udma_create_jfr_resp resp = {};
	urma_cmd_udrv_priv_t udata = {};
	int ret;

	cmd.buf_addr = (uintptr_t)jfr->rq.qbuf;
	cmd.buf_len = jfr->rq.qbuf_size;
	/* JFR only support record db */
	cmd.db_addr = (uintptr_t)jfr->sw_db;
	cmd.jfr_sleep_buf = (uintptr_t)jfr->long_sleeptime;
	cmd.idx_addr = (uintptr_t)jfr->idx_que.buf.buf;
	cmd.idx_len = jfr->idx_que.buf.length;
	cmd.jetty_addr = (uintptr_t)&jfr->rq;
	cmd.non_pin = jfr->rq.cstm;
	cmd.is_hugepage = jfr->rq.hugepage != NULL;

	udma_u_set_udata(&udata, &cmd, sizeof(cmd), &resp, sizeof(resp));
	ret = urma_cmd_create_jfr(ctx, &jfr->base, cfg, &udata);
	if (ret)
		return ret;

	jfr->cap_flags = resp.jfr_caps;
	jfr->rq.idx = jfr->base.jfr_id.id;

	return 0;
}

static void udma_u_init_ring(struct udma_u_idx_ring *ring)
{
	uint32_t i;

	for (i = 0; i < ring->capacity; i++)
		ring->idx[i] = i;

	ring->front = 0;
	ring->rear = i - 1;
}

static struct udma_u_idx_ring *udma_ring_alloc(uint32_t cap)
{
	struct udma_u_idx_ring *ring;
	uint32_t *idx;

	ring = (struct udma_u_idx_ring *)calloc(1, sizeof(*ring));
	if (!ring) {
		UDMA_LOG_ERR("failed to calloc idx ring.\n");
		return NULL;
	}

	idx = (uint32_t *)calloc(cap, sizeof(*idx));
	if (!idx) {
		UDMA_LOG_ERR("failed to calloc idx memory.\n");
		free(ring);
		return NULL;
	}
	ring->idx = idx;
	ring->capacity = cap;

	udma_u_init_ring(ring);

	return ring;
}

static int udma_u_alloc_jfr_idx_que(struct udma_u_jfr *jfr)
{
	struct udma_u_jfr_idx_que *idx_que = &jfr->idx_que;
	uint32_t buf_size;

	idx_que->entry_shift = UDMA_U_ILOG32(UDMA_JFR_IDX_QUE_ENTRY_SZ);
	idx_que->ring = udma_ring_alloc(jfr->wqe_cnt);
	if (!idx_que->ring)
		return ENOMEM;

	buf_size = align(jfr->wqe_cnt << idx_que->entry_shift,
			 UDMA_HW_PAGE_SIZE);
	idx_que->buf.length = align(buf_size, UDMA_HW_PAGE_SIZE);
	idx_que->buf.buf = udma_u_alloc_kernel_buf(jfr->rq.ctx, idx_que->buf.length);
	if (!idx_que->buf.buf) {
		udma_idx_ring_free(idx_que->ring);
		idx_que->ring = NULL;
		return ENOMEM;
	}

	return 0;
}

static void udma_u_free_idx_que(struct udma_u_jfr_idx_que *idx_que)
{
	if (!idx_que->cstm)
		udma_u_free_buf(idx_que->buf.buf, idx_que->buf.length);

	udma_idx_ring_free(idx_que->ring);
}

int udma_u_insert_jfr_node(struct udma_u_context *udma_ctx, struct udma_u_jfr *jfr)
{
	uint32_t jettys_in_tbl = 1 << udma_ctx->jettys_in_tbl_shift;
	uint32_t mask = jettys_in_tbl - 1;
	struct udma_u_jfr **jfr_array;
	uint32_t table_id;

	table_id = jfr->rq.idx >> udma_ctx->jettys_in_tbl_shift;
	pthread_rwlock_wrlock(&udma_ctx->jfr_table_lock);
	if (!udma_ctx->jfr_table[table_id].refcnt) {
		udma_ctx->jfr_table[table_id].jfr_array = (struct udma_u_jfr **)calloc(jettys_in_tbl,
							sizeof(struct udma_u_jfr *));
		if (!udma_ctx->jfr_table[table_id].jfr_array) {
			pthread_rwlock_unlock(&udma_ctx->jfr_table_lock);
			return URMA_ENOMEM;
		}
	}

	jfr_array = udma_ctx->jfr_table[table_id].jfr_array;
	++udma_ctx->jfr_table[table_id].refcnt;
	jfr_array[jfr->rq.idx & mask] = jfr;
	pthread_rwlock_unlock(&udma_ctx->jfr_table_lock);

	return URMA_SUCCESS;
}

urma_jfr_t *udma_u_create_jfr(urma_context_t *ctx, urma_jfr_cfg_t *cfg)
{
	struct udma_u_context *udma_ctx = to_udma_u_ctx(ctx);
	struct udma_u_jfr *udma_jfr;
	int ret;

	if (udma_u_verify_jfr_param(ctx, cfg))
		return NULL;

	udma_jfr = (struct udma_u_jfr *)calloc(1, sizeof(*udma_jfr));
	if (!udma_jfr) {
		UDMA_LOG_ERR("alloc JFR failed.\n");
		return NULL;
	}

	udma_jfr->rq.ctx = udma_ctx;
	udma_u_init_jfr_param(udma_jfr, cfg);

	if (!udma_jfr->lock_free &&
	    pthread_spin_init(&udma_jfr->lock, PTHREAD_PROCESS_PRIVATE))
		goto err_spin_init;

	if (udma_u_alloc_jfr_idx_que(udma_jfr)) {
		UDMA_LOG_ERR("failed to create JFR index queue.\n");
		goto err_alloc_idx;
	}

	if (udma_u_create_rq(udma_ctx, udma_jfr)) {
		UDMA_LOG_ERR("failed to create JFR RQE buffer.\n");
		goto err_create_rq;
	}

	udma_jfr->sw_db = (uint32_t *)udma_u_alloc_sw_db(udma_ctx,
							 UDMA_JFR_TYPE_DB);
	if (!udma_jfr->sw_db)
		goto err_alloc_sw_db;

	udma_jfr->long_sleeptime = (bool *)udma_u_alloc_sw_db(udma_ctx, UDMA_JFR_PAYLOAD);
	if (!udma_jfr->long_sleeptime)
		goto err_alloc_jfr_sleep_buf;

	*udma_jfr->long_sleeptime = false;
	ret = exec_jfr_create_cmd(ctx, udma_jfr, cfg);
	if (ret) {
		UDMA_LOG_ERR("URMA command create JFR failed, ret = %d.\n", ret);
		goto err_exec_cmd;
	}

	if (udma_u_insert_jfr_node(udma_ctx, udma_jfr))
		goto err_insert_node;

	return &udma_jfr->base;

err_insert_node:
	(void)urma_cmd_delete_jfr(&udma_jfr->base);
err_exec_cmd:
	udma_u_free_sw_db(udma_ctx, (uint32_t *)udma_jfr->long_sleeptime, UDMA_JFR_PAYLOAD);
err_alloc_jfr_sleep_buf:
	udma_u_free_sw_db(udma_ctx, udma_jfr->sw_db, UDMA_JFR_TYPE_DB);
err_alloc_sw_db:
	udma_u_free_queue_buf(&udma_jfr->rq);
err_create_rq:
	udma_u_free_idx_que(&udma_jfr->idx_que);
err_alloc_idx:
	if (!udma_jfr->lock_free)
		pthread_spin_destroy(&udma_jfr->lock);
err_spin_init:
	free(udma_jfr);
	return NULL;
}

static void udma_u_jfr_table_remove(struct udma_u_context *udma_ctx,
					     struct udma_u_jfr *jfr)
{
	uint32_t mask = (1 << udma_ctx->jettys_in_tbl_shift) - 1;
	uint32_t table_id = jfr->rq.idx >> udma_ctx->jettys_in_tbl_shift;

	(void)pthread_rwlock_wrlock(&udma_ctx->jfr_table_lock);
	if (udma_ctx->jfr_table[table_id].refcnt == 0) {
		(void)pthread_rwlock_unlock(&udma_ctx->jfr_table_lock);
		return;
	}

	if (!udma_ctx->jfr_table[table_id].jfr_array[jfr->rq.idx & mask]) {
		(void)pthread_rwlock_unlock(&udma_ctx->jfr_table_lock);
		return;
	}
	udma_ctx->jfr_table[table_id].jfr_array[jfr->rq.idx & mask] = NULL;

	if (!--udma_ctx->jfr_table[table_id].refcnt) {
		free(udma_ctx->jfr_table[table_id].jfr_array);
		udma_ctx->jfr_table[table_id].jfr_array = NULL;
	}
	(void)pthread_rwlock_unlock(&udma_ctx->jfr_table_lock);
}

static void udma_u_free_jfr_prepare(urma_jfr_t *jfr)
{
	struct udma_u_context *udma_ctx = to_udma_u_ctx(jfr->urma_ctx);
	struct udma_u_jfr *udma_jfr = to_udma_u_jfr(jfr);

	if (jfr->jfr_cfg.jfc)
		udma_u_clean_jfc(jfr->jfr_cfg.jfc, jfr->jfr_id.id);

	udma_u_free_sw_db(udma_ctx, (uint32_t *)udma_jfr->long_sleeptime, UDMA_JFR_PAYLOAD);

	if (!udma_jfr->swdb_cstm)
		udma_u_free_sw_db(udma_ctx, udma_jfr->sw_db, UDMA_JFR_TYPE_DB);

	udma_u_free_queue_buf(&udma_jfr->rq);
	udma_u_free_idx_que(&udma_jfr->idx_que);

	if (!udma_jfr->lock_free)
		(void)pthread_spin_destroy(&udma_jfr->lock);

	udma_u_jfr_table_remove(udma_ctx, udma_jfr);
}

static void udma_u_free_jfr_detail(urma_jfr_t *jfr)
{
	udma_u_free_jfr_prepare(jfr);
	free(jfr);
}

urma_status_t udma_u_delete_jfr(urma_jfr_t *jfr)
{
	struct udma_u_context *udma_ctx = to_udma_u_ctx(jfr->urma_ctx);
	struct udma_u_jfr *udma_jfr = to_udma_u_jfr(jfr);
	int ret;

	ret = urma_cmd_delete_jfr(jfr);
	if (ret) {
		UDMA_LOG_ERR("URMA command delete JFR failed, ret = %d.\n", ret);
		goto delete_err;
	}
	udma_u_free_jfr_detail(jfr);

	return URMA_SUCCESS;

delete_err:
	udma_u_jfr_table_remove(udma_ctx, udma_jfr);

	return URMA_FAIL;
}

urma_status_t udma_u_delete_jfr_batch(urma_jfr_t **jfr, int jfr_cnt, urma_jfr_t **bad_jfr)
{
	struct udma_u_context *udma_ctx;
	struct udma_u_jfr *udma_jfr;
	int ret;
	int i;

	if (!jfr) {
		UDMA_LOG_ERR("jfr array is null.\n");
		return URMA_EINVAL;
	}

	if (!jfr_cnt) {
		UDMA_LOG_ERR("JFR count is 0.\n");
		return URMA_EINVAL;
	}

	ret = urma_cmd_delete_jfr_batch(jfr, jfr_cnt, bad_jfr);
	if (ret) {
		UDMA_LOG_ERR("URMA command delete JFR failed, ret = %d.\n", ret);
		goto delete_err;
	}

	for (i = 0; i < jfr_cnt; i++)
		udma_u_free_jfr_detail(jfr[i]);

	return URMA_SUCCESS;

delete_err:
	for (i = 0; i < jfr_cnt; i++) {
		udma_ctx = to_udma_u_ctx(jfr[i]->urma_ctx);
		udma_jfr = to_udma_u_jfr(jfr[i]);
		udma_u_jfr_table_remove(udma_ctx, udma_jfr);
	}

	return URMA_FAIL;
}

int udma_verify_modify_jfr(struct udma_u_jfr *jfr, uint32_t jfr_limit)
{
	if (jfr_limit > jfr->wqe_cnt) {
		UDMA_LOG_ERR("JFR limit(%u) larger than wqe num(%u).\n",
			     jfr_limit, jfr->wqe_cnt);
		return EINVAL;
	}

	return 0;
}

static void udma_reset_sw_u_jfr_queue(struct udma_u_jfr *udma_jfr)
{
	udma_u_init_ring(udma_jfr->idx_que.ring);

	udma_jfr->rq.pi = 0;
	udma_jfr->rq.ci = 0;
	*udma_jfr->sw_db = 0;
}

urma_status_t udma_u_modify_jfr(urma_jfr_t *jfr, urma_jfr_attr_t *attr)
{
	struct udma_u_jfr *udma_jfr = to_udma_u_jfr(jfr);
	urma_cmd_udrv_priv_t udata = {};
	int ret;

	if (!(attr->mask & (JFR_RX_THRESHOLD | JFR_STATE))) {
		UDMA_LOG_ERR("modify jfr mask is error or not set, jfr_id = %u.\n",
			     jfr->jfr_id.id);
		return URMA_EINVAL;
	}

	if (attr->mask & JFR_RX_THRESHOLD) {
		ret = udma_verify_modify_jfr(udma_jfr, attr->rx_threshold);
		if (ret) {
			UDMA_LOG_ERR("verify modify JFR failed.\n");
			return URMA_EINVAL;
		}
	}

	ret = urma_cmd_modify_jfr(jfr, attr, &udata);
	if (ret) {
		UDMA_LOG_ERR("URMA command modify JFR failed.\n");
		return URMA_FAIL;
	}

	if ((attr->mask & JFR_STATE) && attr->state == URMA_JFR_STATE_READY)
		udma_reset_sw_u_jfr_queue(udma_jfr);

	return URMA_SUCCESS;
}

urma_status_t udma_u_unimport_jfr(urma_target_jetty_t *target_jfr)
{
	struct udma_u_target_jetty *tjfr = to_udma_u_target_jetty(target_jfr);

	if (urma_cmd_unimport_jfr(target_jfr)) {
		UDMA_LOG_ERR("unimport JFR failed.\n");
		return URMA_FAIL;
	}

	tjfr->token_value = 0;

	free(tjfr);

	return URMA_SUCCESS;
}

static void fill_wqe_idx(struct udma_u_jfr *jfr, uint32_t wqe_idx)
{
	uint32_t *idx_buf;
	uint32_t head;

	head = jfr->rq.pi & (jfr->wqe_cnt - 1);

	idx_buf = (uint32_t *)get_idx_buf(&jfr->idx_que, head);
	*idx_buf = htole32(wqe_idx);

	jfr->rq.pi++;
}

static void fill_recv_sge_to_wqe(urma_jfr_wr_t *wr, void *wqe, struct udma_u_jfr *jfr)
{
	struct udma_wqe_sge *sge = (struct udma_wqe_sge *)wqe;
	uint32_t total_len = 0;
	uint32_t i, cnt;

	for (i = 0, cnt = 0; i < wr->src.num_sge; i++) {
		if (!wr->src.sge[i].len)
			continue;
		total_len += wr->src.sge[i].len;
		set_data_of_sge(sge + cnt, wr->src.sge + i);
		cnt++;
	}

	if (total_len > UDMA_JFR_LARGE_PACKAGE)
		*jfr->long_sleeptime = true;

	if (cnt < jfr->max_sge)
		(void)memset(sge + cnt, 0, (jfr->max_sge - cnt) * UDMA_SGE_SIZE);
}

static void udma_ring_use_idx(struct udma_u_idx_ring *ring, uint32_t *idx)
{
	*idx = ring->idx[ring->front];

	ring->front++;
	if (ring->front >= ring->capacity)
		ring->front = 0;
}

static urma_status_t post_recv_one(struct udma_u_jfr *jfr, urma_jfr_wr_t *wr)
{
	urma_status_t ret = URMA_SUCCESS;
	uint32_t wqe_idx;
	void *wqe;

	if (wr->src.num_sge > jfr->max_sge) {
		UDMA_LOG_ERR("failed to check SGE, WR_SGE number = %u, max_SGE = %u, JFR number = %u.\n",
			     wr->src.num_sge, jfr->max_sge, jfr->base.jfr_id.id);
		return URMA_EINVAL;
	}

	if (udma_jfrwq_overflow(jfr)) {
		UDMA_LOG_ERR("failed to check JFR work queue status, JFR work queue is full, JFR number = %u.\n",
			     jfr->base.jfr_id.id);
		return URMA_ENOMEM;
	}

	udma_ring_use_idx(jfr->idx_que.ring, &wqe_idx);
	wqe = get_jfr_wqe(jfr, wqe_idx);

	fill_recv_sge_to_wqe(wr, wqe, jfr);
	fill_wqe_idx(jfr, wqe_idx);

	jfr->rq.wrid[wqe_idx] = wr->user_ctx;

	return ret;
}

urma_status_t udma_u_post_jfr_wr(urma_jfr_t *jfr, urma_jfr_wr_t *wr,
				 urma_jfr_wr_t **bad_wr)
{
	struct udma_u_jfr *udma_jfr = to_udma_u_jfr(jfr);
	urma_status_t ret = URMA_SUCCESS;
	uint32_t nreq;

	if (!udma_jfr->lock_free)
		(void)pthread_spin_lock(&udma_jfr->lock);

	for (nreq = 0; wr; ++nreq, wr = wr->next) {
		ret = post_recv_one(udma_jfr, wr);
		if (ret) {
			*bad_wr = wr;
			break;
		}
	}

	if (nreq) {
		UDMA_TO_DEVICE_BARRIER();
		*udma_jfr->sw_db = udma_jfr->rq.pi & UDMA_JFR_DB_PROD_IDX_M;
	}

	if (!udma_jfr->lock_free)
		(void)pthread_spin_unlock(&udma_jfr->lock);

	return ret;
}

urma_status_t udma_u_query_jfr(urma_jfr_t *jfr, urma_jfr_cfg_t *cfg,
			       urma_jfr_attr_t *attr)
{
	int ret;

	ret = urma_cmd_query_jfr(jfr, cfg, attr);
	if (ret) {
		UDMA_LOG_ERR("failed to query JFR in URMA command, ret = %d.\n", ret);
		return URMA_FAIL;
	}

	return URMA_SUCCESS;
}

urma_target_jetty_t *udma_u_import_jfr_ex(urma_context_t *ctx,
					  urma_rjfr_t *rjfr,
					  urma_token_t *token_value,
					  urma_active_tp_cfg_t *active_tp_cfg)
{
	struct udma_u_target_jetty *tjfr;
	urma_tjfr_cfg_t cfg;

	tjfr = (struct udma_u_target_jetty *)calloc(1, sizeof(*tjfr));
	if (tjfr == NULL) {
		UDMA_LOG_ERR("failed to alloc target JFR in exp process.\n");
		return NULL;
	}

	cfg.token = token_value;
	cfg.jfr_id = rjfr->jfr_id;
	cfg.trans_mode = rjfr->trans_mode;
	cfg.tp_type = rjfr->tp_type;
	cfg.flag = rjfr->flag;
	if (rjfr->flag.bs.token_policy != URMA_TOKEN_NONE) {
		tjfr->token_value = token_value->token;
		tjfr->token_value_valid = true;
	}

	if (urma_cmd_import_jfr_ex(ctx, &tjfr->urma_tjetty,
				   &cfg, (urma_import_jfr_ex_cfg_t *)active_tp_cfg, NULL) != 0) {
		UDMA_LOG_ERR("ubcore export import JFR failed.\n");
		free(tjfr);
		return NULL;
	}

	udma_u_swap_endian128(rjfr->jfr_id.eid.raw, tjfr->le_eid.raw);

	return &tjfr->urma_tjetty;
}

static int udma_u_active_jfr_cmd(struct udma_u_jfr *jfr)
{
	struct udma_create_jetty_ucmd cmd = {};
	struct udma_create_jfr_resp resp = {};
	urma_cmd_udrv_priv_t udata = {};
	int ret;

	cmd.buf_addr = (uintptr_t)jfr->rq.qbuf;
	cmd.buf_len = jfr->rq.qbuf_size;

	cmd.db_addr = (uintptr_t)jfr->sw_db;
	cmd.jfr_sleep_buf = (uintptr_t)jfr->long_sleeptime;
	cmd.idx_addr = (uintptr_t)jfr->idx_que.buf.buf;
	cmd.idx_len = jfr->idx_que.buf.length;
	cmd.jetty_addr = (uintptr_t)&jfr->rq;
	cmd.non_pin = jfr->rq.cstm;
	cmd.is_hugepage = jfr->rq.hugepage != NULL;

	udma_u_set_udata(&udata, &cmd, sizeof(cmd), &resp, sizeof(resp));
	ret = urma_cmd_active_jfr(&jfr->base, &udata);
	if (ret)
		return ret;

	jfr->cap_flags = resp.jfr_caps;
	jfr->rq.idx = jfr->base.jfr_id.id;

	return 0;
}

urma_status_t udma_u_alloc_jfr(urma_context_t *ctx, urma_jfr_cfg_t *cfg, urma_jfr_t **jfr)
{
	struct udma_u_context *udma_ctx = to_udma_u_ctx(ctx);
	urma_cmd_udrv_priv_t udata = {};
	struct udma_u_jfr *udma_jfr;
	int ret;

	udma_jfr = (struct udma_u_jfr *)calloc(1, sizeof(*udma_jfr));
	if (!udma_jfr) {
		UDMA_LOG_ERR("calloc JFR is NULL.\n");
		return URMA_ENOMEM;
	}

	ret = urma_cmd_alloc_jfr(ctx, cfg, &udma_jfr->base, &udata);
	if (ret) {
		UDMA_LOG_ERR("urma cmd alloc JFR failed, ret = %d.\n", ret);
		free(udma_jfr);
		udma_jfr = NULL;
		return URMA_FAIL;
	}
	*jfr = &udma_jfr->base;
	udma_jfr->rq.ctx = udma_ctx;

	return URMA_SUCCESS;
}

urma_status_t udma_u_free_jfr(urma_jfr_t *jfr)
{
	urma_cmd_udrv_priv_t udata = {};

	if (urma_cmd_free_jfr(jfr, &udata)) {
		UDMA_LOG_ERR("failed to free user JFR.\n");
		return URMA_FAIL;
	}

	free(jfr);

	return URMA_SUCCESS;
}

urma_status_t udma_u_active_jfr(urma_jfr_t *jfr)
{
	struct udma_u_context *udma_ctx = to_udma_u_ctx(jfr->urma_ctx);
	struct udma_u_jfr *udma_jfr = to_udma_u_jfr(jfr);
	urma_jfr_cfg_t *jfr_cfg = &jfr->jfr_cfg;
	urma_cmd_udrv_priv_t udata = {};
	int ret;

	if (udma_u_verify_jfr_param(jfr->urma_ctx, jfr_cfg))
		return URMA_EINVAL;

	udma_u_init_jfr_param(udma_jfr, jfr_cfg);
	if (!udma_jfr->lock_free &&
	    pthread_spin_init(&udma_jfr->lock, PTHREAD_PROCESS_PRIVATE))
		return URMA_FAIL;

	if (udma_u_alloc_jfr_idx_que(udma_jfr)) {
		UDMA_LOG_ERR("failed to alloc JFR index queue.\n");
		goto err_alloc_idx;
	}

	if (udma_u_create_rq(udma_ctx, udma_jfr)) {
		UDMA_LOG_ERR("failed to create JFR RQE buffer.\n");
		goto err_create_rq;
	}

	if (!udma_jfr->swdb_cstm) {
		udma_jfr->sw_db = (uint32_t *)udma_u_alloc_sw_db(udma_ctx, UDMA_JFR_TYPE_DB);
		if (!udma_jfr->sw_db) {
			UDMA_LOG_ERR("failed to alloc SW DB.\n");
			goto err_alloc_sw_db;
		}

		udma_jfr->long_sleeptime = (bool *)udma_u_alloc_sw_db(udma_ctx, UDMA_JFR_PAYLOAD);
		if (!udma_jfr->long_sleeptime) {
			UDMA_LOG_ERR("failed to alloc SW DB for payload.\n");
			goto err_alloc_jfr_sleep_buf;
		}
		*udma_jfr->long_sleeptime = false;
	}

	ret = udma_u_active_jfr_cmd(udma_jfr);
	if (ret) {
		UDMA_LOG_ERR("failed to activate JFR command, ret = %d.\n", ret);
		goto err_active_cmd;
	}

	if (udma_u_insert_jfr_node(udma_ctx, udma_jfr))
		goto err_insert_node;

	return URMA_SUCCESS;

err_insert_node:
	urma_cmd_deactive_jfr(&udma_jfr->base, &udata);
err_active_cmd:
	if (!udma_jfr->swdb_cstm)
		udma_u_free_sw_db(udma_ctx, (uint32_t *)udma_jfr->long_sleeptime, UDMA_JFR_PAYLOAD);
err_alloc_jfr_sleep_buf:
	if (!udma_jfr->swdb_cstm)
		udma_u_free_sw_db(udma_ctx, udma_jfr->sw_db, UDMA_JFR_TYPE_DB);
err_alloc_sw_db:
	udma_u_free_queue_buf(&udma_jfr->rq);
err_create_rq:
	udma_u_free_idx_que(&udma_jfr->idx_que);
err_alloc_idx:
	if (!udma_jfr->lock_free)
		pthread_spin_destroy(&udma_jfr->lock);

	return URMA_FAIL;
}

static int udma_u_set_jfr_param(urma_jfr_t *jfr, uint64_t opt, void *buf)
{
	struct udma_u_jfr *udma_jfr = to_udma_u_jfr(jfr);

	switch (opt) {
	case URMA_JFR_DEPTH:
	case URMA_JFR_FLAG:
	case URMA_JFR_TRANS_MODE:
	case URMA_JFR_MAX_SGE:
	case URMA_JFR_MIN_RNR_TIMER:
	case URMA_JFR_BIND_JFC:
	case URMA_JFR_TOKEN_VALUE:
		break;
	case URMA_JFR_USER_CTX:
		return URMA_EEXIST;
	case URMA_JFR_RQE_BASE_ADDR:
		udma_jfr->rq.qbuf = (void *)(uintptr_t)(*((uint64_t *)buf));
		if (!(udma_jfr->rq.qbuf)) {
			UDMA_LOG_ERR("failed to set RQ address.\n");
			return URMA_EINVAL;
		}
		udma_jfr->rq.cstm = true;
		break;
	case URMA_JFR_ID:
		udma_jfr->rq.idx = *((uint32_t *)buf);
		break;
	case URMA_JFR_DB_ADDR:
		udma_jfr->sw_db = (void *)(uintptr_t)(*((uint64_t *)buf));
		if (!(udma_jfr->sw_db)) {
			UDMA_LOG_ERR("failed to set doorbell address.\n");
			return URMA_EINVAL;
		}
		udma_jfr->swdb_cstm = true;
		break;
	case URMA_JFR_DB_STATUS:
	case URMA_JFR_PI_TYPE:
		break;
	default:
		UDMA_LOG_ERR("invalid parameter, option=%lu.\n", opt);
		return URMA_EINVAL;
	}

	return 0;
}

static int udma_u_get_jfr_param(urma_jfr_t *jfr, uint64_t opt, void *buf, uint32_t len)
{
	struct udma_u_jfr *udma_jfr = to_udma_u_jfr(jfr);
	urma_cmd_udrv_priv_t udata = {};

	switch (opt) {
	case URMA_JFR_DEPTH:
		*((uint32_t *)buf) = (jfr->jfr_cfg.depth);
		break;
	case URMA_JFR_FLAG:
		*((uint32_t *)buf) = (jfr->jfr_cfg.flag.value);
		break;
	case URMA_JFR_TRANS_MODE:
		*((uint32_t *)buf) = (jfr->jfr_cfg.trans_mode);
		break;
	case URMA_JFR_MAX_SGE:
		*((uint8_t *)buf) = (jfr->jfr_cfg.max_sge);
		break;
	case URMA_JFR_MIN_RNR_TIMER:
		*((uint8_t *)buf) = (jfr->jfr_cfg.min_rnr_timer);
		break;
	case URMA_JFR_BIND_JFC:
		*((uint64_t *)buf) = (uint64_t)(uintptr_t)(jfr->jfr_cfg.jfc);
		break;
	case URMA_JFR_TOKEN_VALUE:
		*((uint32_t *)buf) = jfr->jfr_cfg.token_value.token;
		break;
	case URMA_JFR_USER_CTX:
		*((uint64_t *)buf) = jfr->jfr_cfg.user_ctx;
		break;
	case URMA_JFR_RQE_BASE_ADDR:
		*((uint64_t *)buf) = (uint64_t)(uintptr_t)udma_jfr->rq.qbuf;
		break;
	case URMA_JFR_ID:
		*((uint32_t *)buf) = udma_jfr->rq.idx;
		break;
	case URMA_JFR_DB_ADDR:
		*((uint64_t *)buf) = (uint64_t)(uintptr_t)udma_jfr->sw_db;
		break;
	case URMA_JFR_DB_STATUS:
	case URMA_JFR_PI_TYPE:
		break;
	case URMA_JFR_PI:
	case URMA_JFR_CI:
		break;
	case URMA_JFR_FULL_CTX:
		return urma_cmd_get_jfr_opt(jfr, opt, buf, len, &udata);
	default:
		UDMA_LOG_ERR("invalid parameter, option=%lu.\n", opt);
		return URMA_EINVAL;
	}

	return 0;
}

static struct udma_u_jfr_opt_info opt_u_jfr_table[] = {
	{URMA_JFR_DEPTH, sizeof(uint32_t), PERM_READ | PERM_WRITE},
	{URMA_JFR_FLAG, sizeof(uint32_t), PERM_READ | PERM_WRITE},
	{URMA_JFR_TRANS_MODE, sizeof(uint32_t), PERM_READ | PERM_WRITE},
	{URMA_JFR_MAX_SGE, sizeof(uint8_t), PERM_READ | PERM_WRITE},
	{URMA_JFR_MIN_RNR_TIMER , sizeof(uint8_t), PERM_READ | PERM_WRITE},
	{URMA_JFR_BIND_JFC, sizeof(uint64_t), PERM_READ | PERM_WRITE},
	{URMA_JFR_TOKEN_VALUE, sizeof(uint32_t), PERM_READ | PERM_WRITE},
	{URMA_JFR_USER_CTX, sizeof(uint64_t), PERM_READ | PERM_WRITE},
	{URMA_JFR_RQE_BASE_ADDR, sizeof(uint64_t), PERM_READ | PERM_WRITE},
	{URMA_JFR_ID, sizeof(uint32_t), PERM_READ | PERM_WRITE},
	{URMA_JFR_DB_ADDR, sizeof(uint64_t), PERM_READ | PERM_WRITE},
	{URMA_JFR_DB_STATUS, sizeof(uint8_t), PERM_READ | PERM_WRITE},
	{URMA_JFR_PI, sizeof(uint16_t), PERM_READ},
	{URMA_JFR_PI_TYPE, sizeof(uint16_t), PERM_READ | PERM_WRITE},
	{URMA_JFR_CI, sizeof(uint16_t), PERM_READ},
	{URMA_JFR_FULL_CTX, UDMA_JFR_CTX_SIZE, PERM_READ},
};

static int udma_u_check_set_get_jfr_param(uint64_t opt, void *buf, uint32_t len,
					  enum udma_set_get_jfr_opt_perm perm)
{
	if (!buf) {
		UDMA_LOG_ERR("invalid parameter, buffer is NULL.\n");
		return EINVAL;
	}

	for (size_t i = 0; i < ARRAY_SIZE(opt_u_jfr_table); i++) {
		if ((opt_u_jfr_table[i].opt == opt) && (opt_u_jfr_table[i].buf_len == len) &&
		    (opt_u_jfr_table[i].perm & perm))
			return 0;
	}
	UDMA_LOG_ERR("invalid parameter, length = %u, option = %lu.\n", len, opt);

	return EINVAL;
}

urma_status_t udma_u_set_jfr_opt(urma_jfr_t *jfr, uint64_t opt, void *buf, uint32_t len)
{
	urma_cmd_udrv_priv_t udata = {};
	int ret;

	ret = udma_u_check_set_get_jfr_param(opt, buf, len, PERM_WRITE);
	if (ret)
		return URMA_EINVAL;

	ret = udma_u_set_jfr_param(jfr, opt, buf);
	if (ret == URMA_EEXIST)
		return URMA_SUCCESS;
	if (ret)
		return URMA_FAIL;

	ret = urma_cmd_set_jfr_opt(jfr, opt, buf, len, &udata);
	if (ret) {
		UDMA_LOG_ERR("failed to set user JFR, option=%lu, ret = %d.\n", opt, ret);
		return URMA_FAIL;
	}

	return URMA_SUCCESS;
}

urma_status_t udma_u_get_jfr_opt(urma_jfr_t *jfr, uint64_t opt, void *buf, uint32_t len)
{
	urma_cmd_udrv_priv_t udata = {};
	int ret;

	ret = udma_u_check_set_get_jfr_param(opt, buf, len, PERM_READ);
	if (ret)
		return URMA_FAIL;

	if (opt != URMA_JFR_USER_CTX) {
		ret = urma_cmd_get_jfr_opt(jfr, opt, buf, len, &udata);
		if (ret) {
			UDMA_LOG_ERR("failed to get JFR option, option=%lu, ret = %d.\n", opt, ret);
			return URMA_FAIL;
		}
	}
	ret = udma_u_get_jfr_param(jfr, opt, buf, len);
	if (ret) {
		UDMA_LOG_ERR("failed to get user JFR parameter, option=%lu, ret = %d.\n", opt, ret);
		return URMA_FAIL;
	}

	return URMA_SUCCESS;
}

urma_status_t udma_u_deactive_jfr(urma_jfr_t *jfr)
{
	struct udma_u_context *udma_ctx = to_udma_u_ctx(jfr->urma_ctx);
	struct udma_u_jfr *udma_jfr = to_udma_u_jfr(jfr);
	urma_cmd_udrv_priv_t udata = {};
	int ret;

	ret = urma_cmd_deactive_jfr(jfr, &udata);
	if (ret) {
		UDMA_LOG_ERR("failed to deactivate JFR, ret = %d.\n", ret);
		udma_u_jfr_table_remove(udma_ctx, udma_jfr);
		return URMA_FAIL;
	}

	udma_u_free_jfr_prepare(jfr);

	return URMA_SUCCESS;
}
