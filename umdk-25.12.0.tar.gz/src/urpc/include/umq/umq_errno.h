/*
 * SPDX-License-Identifier: MIT
 * Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
 * Description: Public header file of UMQ errno
 * Create: 2025-7-16
 * Note:
 * History: 2025-7-16
 */

#ifndef UMQ_ERRNO_H
#define UMQ_ERRNO_H

#include <errno.h>

#ifdef __cplusplus
extern "C" {
#endif

#define UMQ_SUCCESS                                (0)
#define UMQ_FAIL                                   (-1)
#define UMQ_INVALID_HANDLE                         (0)
#define UMQ_INVALID_FD                             (-1)

#define UMQ_ERR_EPERM                              (EPERM)
#define UMQ_ERR_EAGAIN                             (EAGAIN)
#define UMQ_ERR_ENOMEM                             (ENOMEM)
#define UMQ_ERR_EBUSY                              (EBUSY)
#define UMQ_ERR_EEXIST                             (EEXIST)
#define UMQ_ERR_EINVAL                             (EINVAL)
#define UMQ_ERR_ENODEV                             (ENODEV)
#define UMQ_ERR_ENOSR                              (ENOSR)  /* Out of streams resources, like Jetty/TP */
#define UMQ_ERR_EFAULT                             (EFAULT)
#define UMQ_ERR_EMLINK                             (EMLINK)
#define UMQ_ERR_ENOBUFS                            (ENOBUFS)
#define UMQ_ERR_ETIMEOUT                           (ETIMEDOUT)
#define UMQ_ERR_EINPROGRESS                        (EINPROGRESS)
#define UMQ_ERR_ETOOMANYREFS                       (ETOOMANYREFS)
#define UMQ_ERR_ETSEG_NON_IMPORTED                 (0x0201)
#define UMQ_ERR_EFLOWCTL                           (0x0202)  /* Umq flow control error */
#define UMQ_ERR_EFLOWCTL_FATAL                     (0x0203)
#define UMQ_ERR_EFLOWCTL_EAGAIN                    (0x0204)

typedef enum umq_buf_status {
    UMQ_BUF_SUCCESS = 0,
    UMQ_BUF_UNSUPPORTED_OPCODE_ERR,     /* Opcode in the WR is not supported */
    UMQ_BUF_LOC_LEN_ERR,                /* Local data too long error */
    UMQ_BUF_LOC_OPERATION_ERR,          /* Local operation err */
    UMQ_BUF_LOC_ACCESS_ERR,             /* Access to local memory error */
    UMQ_BUF_REM_RESP_LEN_ERR,           /* Local Operation Error, with sub-status of Remote Response Length Error */
    UMQ_BUF_REM_UNSUPPORTED_REQ_ERR,
    UMQ_BUF_REM_OPERATION_ERR,          /* Error when target jetty can not complete the operation */
    UMQ_BUF_REM_ACCESS_ABORT_ERR,       /* Error when target jetty access memory error or abort the operation */
    UMQ_BUF_ACK_TIMEOUT_ERR,            /* Retransmission exceeds the maximum number of times */
    UMQ_BUF_RNR_RETRY_CNT_EXC_ERR,      /* RNR retries exceeded the maximum number: remote jfr has no buffer */
    UMQ_BUF_WR_FLUSH_ERR,               /* Jetty in the error state, and the hardware has processed the WR. */
    UMQ_BUF_WR_SUSPEND_DONE,            /* Hardware constructs a fake CQE, and user_ctx is invalid. */
    UMQ_BUF_WR_FLUSH_ERR_DONE,          /* Hardware constructs a fake CQE, and user_ctx is invalid. */
    UMQ_BUF_WR_UNHANDLED,               /* Return of flush jetty/jfs, and the hardware has not processed the WR. */
    UMQ_BUF_LOC_DATA_POISON,            /* Local Data Poison */
    UMQ_BUF_REM_DATA_POISON,            /* Remote Data Poison */

    UMQ_BUF_RNR_RETRY_CNT_EXC = 99,     /* RNR retries: reduce the post frequency and do not free qbuf */

    UMQ_BUF_FLOW_CONTROL_UPDATE = 128,  /* Umq flow control window is updated, this is not error case */
    UMQ_MEMPOOL_UPDATE_SUCCESS,
    UMQ_MEMPOOL_UPDATE_FAILED,
    UMQ_IMPORT_TSEG_SUCCESS,
    UMQ_IMPORT_TSEG_FAILED,

    // fake buf
    UMQ_FAKE_BUF_FC_UPDATE = 192,       /* Umq fake flow control window is updated, this is not error case */
    UMQ_FAKE_BUF_FC_MSG,                /* Umq fake flow control received request, this is not error case */
    UMQ_FAKE_BUF_FC_ERR,                /* Umq fake flow control error, CR status is abnormal */
    UMQ_FAKE_BUF_FC_EMLINK,             /* Umq fake flow control error, no available transmission resources */
    UMQ_FAKE_BUF_FC_ERR_FATAL,          /* Umq fake flow control fatal error */
    UMQ_FAKE_BUF_MAX = 256,
} umq_buf_status_t;

#ifdef __cplusplus
}
#endif

#endif