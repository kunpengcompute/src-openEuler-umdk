/*
 * SPDX-License-Identifier: MIT
 * Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
 * Description: Internal header file of UMQ function
 * Create: 2025-7-17
 * Note:
 * History: 2025-7-17
 */

#ifndef UMQ_INNER_API_H
#define UMQ_INNER_API_H

#include <time.h>

#include "urpc_util.h"
#include "urpc_thread_closure.h"
#include "umq_api.h"
#include "umq_pro_api.h"
#include "umq_tp_api.h"
#include "umq_pro_tp_api.h"
#include "umq_tp_dfx_api.h"

#ifdef __cplusplus
extern "C" {
#endif

#define UMQ_EID_MAP_PREFIX              (0x0000ffff)
#define UMQ_DEFAULT_BUF_SIZE            4096
#define UMQ_DEFAULT_DEPTH               1024
#define UMQ_MAX_QUEUE_NUMBER            8192
#define UMQ_SIZE_4M                     (0x400000)
#define SHM_MODE (0660)
#define UMQ_MAX_SGE_NUM 1

typedef struct umq {
    umq_trans_mode_t mode;
    umq_ops_t *tp_ops;
    umq_pro_ops_t *pro_tp_ops;
    umq_dfx_ops_t *dfx_tp_ops;
    uint64_t umqh_tp;
} umq_t;

static inline uint32_t umq_get_post_rx_num(uint32_t rx_depth, volatile uint32_t *require_rx_count)
{
    if (rx_depth <= UMQ_BATCH_SIZE) {
        return __atomic_exchange_n(require_rx_count, 0, __ATOMIC_ACQ_REL);
    }

    unsigned int rx_num = (uint32_t)__atomic_load_n(require_rx_count, __ATOMIC_ACQUIRE);
    do {
        if (rx_num < UMQ_BATCH_SIZE) {
            return 0;
        }
    } while (!__atomic_compare_exchange_n(require_rx_count, &rx_num, 0, true, __ATOMIC_ACQ_REL, __ATOMIC_ACQUIRE));
    return rx_num;
}

static inline void umq_inc_ref(bool lock_free, volatile uint32_t *ref_cnt, uint32_t n)
{
    if (lock_free) {
        *ref_cnt = *ref_cnt + n;
    } else {
        (void)__atomic_fetch_add(ref_cnt, n, __ATOMIC_RELAXED);
    }
}

static inline void umq_dec_ref(bool lock_free, volatile uint32_t *ref_cnt, uint32_t n)
{
    if (lock_free) {
        *ref_cnt = *ref_cnt - n;
    } else {
        (void)__atomic_fetch_sub(ref_cnt, n, __ATOMIC_ACQ_REL);
    }
}

static inline uint32_t umq_fetch_ref(bool lock_free, volatile uint32_t *ref_cnt)
{
    if (lock_free) {
        return *ref_cnt;
    } else {
        return (uint32_t)__atomic_load_n(ref_cnt, __ATOMIC_ACQUIRE);
    }
}

static ALWAYS_INLINE bool is_timeout(const struct timespec *last, uint32_t timeout)
{
    struct timespec now;
    (void)clock_gettime(CLOCK_MONOTONIC, &now);

    uint64_t t1 = (uint64_t)(last->tv_sec * NS_PER_SEC + last->tv_nsec);
    uint64_t t2 = (uint64_t)(now.tv_sec * NS_PER_SEC + now.tv_nsec);
    uint64_t t3 = (uint64_t)timeout * NS_PER_MS;

    return (t2 >= t1) && (t2 - t1) >= t3;
}

umq_dfx_ops_t *umq_get_dfx_tp_ops(umq_trans_mode_t trans_mode);

void umq_io_perf_process(umq_perf_record_type_t record_type, umq_buf_t *qbuf);
int umq_thread_closure_register(umq_trans_mode_t trans_mode,
    urpc_thread_closure_type_t type, uint64_t id, void (*closure)(uint64_t id));

#ifdef __cplusplus
}
#endif

#endif
