/*
 * SPDX-License-Identifier: MIT
 * Copyright (c) Huawei Technologies Co., Ltd. 2026-2026. All rights reserved.
 * Description: shmem combine tiling header file
 * Create: 2026-01-06
 * Note:
 * History: 2026-01-06 create shmem combine tiling header file
 */

#ifndef ASCENDC_COMM_MOE_COMBINE_SHMEM_TILING_H
#define ASCENDC_COMM_MOE_COMBINE_SHMEM_TILING_H

#include <cstdint>
#include "kernel_tiling/kernel_tiling.h"

// a3
namespace Moe {
struct MoeCombineShmemInfo {
    uint32_t epWorldSize;  // epWorldSize
    uint32_t tpWorldSize;  // tpWorldSize
    uint32_t epRankId;
    uint32_t tpRankId;
    uint32_t expertShardType;
    uint32_t sharedExpertRankNum;
    uint32_t moeExpertNum;
    uint32_t moeExpertPerRankNum;
    uint32_t globalBs;
    uint32_t bs;
    uint32_t k;
    uint32_t h;
    uint32_t aivNum;
    uint64_t totalUbSize;
    uint64_t totalWinSize;
    uint64_t magic;
    uint64_t shmemPtr;  // shmem ptr
};
struct MoeCombineShmemTilingData {
    Mc2InitTiling mc2InitTiling;
    Mc2CcTiling mc2CcTiling1;
    Mc2CcTiling mc2CcTiling2;
    MoeCombineShmemInfo moeDistributeCombineInfo;
};
} // namespace Moe
#endif  //__ASCENDC_COMM_MOE_COMBINE_SHMEM_TILING_H__
