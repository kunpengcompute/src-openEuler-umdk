/*
 * SPDX-License-Identifier: MIT
 * Copyright (c) Huawei Technologies Co., Ltd. 2026-2026. All rights reserved.
 * Description: Bond provider datapath schedule implementation file
 * Author: Wang Hang
 * Create: 2026-04-06
 * Note:
 * History: 2026-04-06   Create File
 */

#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "bondp_health_check.h"
#include "bondp_types.h"
#include "urma_log.h"

#include "bondp_datapath_schedule.h"

static urma_transport_mode_t get_comp_urma_trans_mode(const bondp_comp_t *bdp_comp)
{
    switch (bdp_comp->comp_type) {
        case BONDP_COMP_JFS:
            return bdp_comp->v_jfs.jfs_cfg.trans_mode;
        case BONDP_COMP_JETTY:
            return bdp_comp->v_jetty.jetty_cfg.jfs_cfg.trans_mode;
        case BONDP_COMP_JFR:
            return bdp_comp->v_jfr.jfr_cfg.trans_mode;
        default:
            return URMA_TM_RM;
    }
}

static void select_least_load_path(const bondp_comp_t *bdp_comp, const bondp_target_jetty_t *bdp_tjetty,
                                   uint32_t min_idx[], uint32_t max_idx[], bondp_path_t least_load_path[],
                                   uint32_t *least_load_cnt)
{
    uint32_t least_load = UINT32_MAX;
    urma_transport_mode_t trans_mode = get_comp_urma_trans_mode(bdp_comp);

    *least_load_cnt = 0;
    for (uint32_t i = 0; i < bdp_comp->active_count; i++) {
        uint32_t local_idx = bdp_comp->active_indices[i];
        if (!atomic_load(&bdp_comp->valid[local_idx]) || local_idx < min_idx[0] || local_idx >= max_idx[0]) {
            continue;
        }
        for (uint32_t j = 0; j < bdp_tjetty->active_count; j++) {
            uint32_t target_idx = bdp_tjetty->active_indices[j];
            if (!atomic_load(&bdp_tjetty->valid[target_idx]) || target_idx < min_idx[1] || target_idx >= max_idx[1] ||
                bdp_tjetty->p_tjetty[local_idx][target_idx] == NULL) {
                continue;
            }
            if (trans_mode == URMA_TM_RC && bdp_comp->comp_type == BONDP_COMP_JETTY &&
                bdp_comp->p_jetty[local_idx]->remote_jetty != bdp_tjetty->p_tjetty[local_idx][target_idx]) {
                continue;
            }
            uint32_t sqe_cnt = atomic_load(&bdp_comp->sqe_cnt[local_idx][target_idx]);
            if (sqe_cnt < least_load) {
                least_load = sqe_cnt;
                least_load_path[0].local_idx = local_idx;
                least_load_path[0].target_idx = target_idx;
                *least_load_cnt = 1;
            } else if (sqe_cnt == least_load) {
                least_load_path[(*least_load_cnt)].local_idx = local_idx;
                least_load_path[(*least_load_cnt)].target_idx = target_idx;
                (*least_load_cnt)++;
            }
        }
    }
}

static __thread struct random_data schedule_rand_data;
static __thread char schedule_rand_state[32] = {0};
static __thread bool schedule_rand_inited = false;

static uint32_t select_random_path(uint32_t candidate_cnt)
{
    uint32_t selected_pos;
    int32_t rand_val;

    if (!schedule_rand_inited) {
        unsigned int seed = (unsigned int)time(NULL) ^ (unsigned int)getpid() ^
                            (unsigned int)(uintptr_t)pthread_self();
        (void)memset(&schedule_rand_data, 0, sizeof(schedule_rand_data));
        (void)initstate_r((unsigned int)seed, schedule_rand_state, sizeof(schedule_rand_state),
                          &schedule_rand_data);
        schedule_rand_inited = true;
    }

    (void)random_r(&schedule_rand_data, &rand_val);
    selected_pos = (uint32_t)rand_val % candidate_cnt;
    return selected_pos;
}

static int schedule_send_standalone(const bondp_comp_t *bdp_comp, const bondp_target_jetty_t *bdp_tjetty,
                                    int *send_idx, int *target_idx)
{
    uint32_t loc_idx = bdp_comp->active_indices[0];

    if (!atomic_load(&bdp_comp->valid[loc_idx])) {
        return -1;
    }
    for (uint32_t j = 0; j < bdp_tjetty->active_count; j++) {
        uint32_t tar_idx = bdp_tjetty->active_indices[j];
        if (!atomic_load(&bdp_tjetty->valid[tar_idx]) || bdp_tjetty->p_tjetty[loc_idx][tar_idx] == NULL) {
            continue;
        }
        *send_idx = (int)loc_idx;
        *target_idx = (int)tar_idx;
        return 0;
    }
    return -1;
}

static int schedule_send_active_backup(const bondp_comp_t *bdp_comp, const bondp_target_jetty_t *bdp_tjetty,
                                       int *send_idx, int *target_idx)
{
    bool target_used[URMA_UBAGG_DEV_MAX_NUM] = {0};

    // active_backup mode only use 4 paths
    for (uint32_t i = 0; i < bdp_comp->active_count; i++) {
        uint32_t loc_idx = bdp_comp->active_indices[i];
        for (uint32_t j = 0; j < bdp_tjetty->active_count; j++) {
            uint32_t tar_idx = bdp_tjetty->active_indices[j];
            if (!atomic_load(&bdp_tjetty->valid[tar_idx]) ||
                bdp_tjetty->p_tjetty[loc_idx][tar_idx] == NULL ||
                target_used[tar_idx]) {
                continue;
            }
            if (atomic_load(&bdp_comp->valid[loc_idx])) {
                *send_idx = (int)loc_idx;
                *target_idx = (int)tar_idx;
                return 0;
            }
            target_used[tar_idx] = true;
            break;
        }
    }

    return -1;
}

static int get_affinity_path_range_ex(const bondp_comp_t *bdp_comp, const uint32_t chip_id,
                                      uint32_t *min, uint32_t *max)
{
    switch (bdp_comp->bondp_ctx->bonding_level) {
        case BONDP_BONDING_LEVEL_IODIE:
            *min = chip_id - BONDP_CHIP_ID_MIN;
            *max = *min + 1;
            return 0;
        case BONDP_BONDING_LEVEL_PORT:
            if (chip_id == BONDP_CHIP_ID_MIN) {
                const uint32_t affinity_port_start = 2;
                const uint32_t affinity_port_end = 11;
                *min = affinity_port_start;
                *max = affinity_port_end;
            } else {
                const uint32_t affinity_port_start = 11;
                const uint32_t affinity_port_end = 20;
                *min = affinity_port_start;
                *max = affinity_port_end;
            }
            return 0;
        default:
            URMA_LOG_ERR("Unsupported bonding level=%d.\n", bdp_comp->bondp_ctx->bonding_level);
            return URMA_EINVAL;
    }
}

static int get_affinity_path_range(const bondp_comp_t *bdp_comp, const bondp_chip_id_info_t *info,
                                   uint32_t min[], uint32_t max[])
{
    if (get_affinity_path_range_ex(bdp_comp, info->src_chip_id, &min[0], &max[0]) != 0 ||
        get_affinity_path_range_ex(bdp_comp, info->dst_chip_id, &min[1], &max[1]) != 0) {
        return URMA_EINVAL;
    }
    return 0;
}

static int schedule_send_balance(const bondp_comp_t *bdp_comp, const bondp_target_jetty_t *bdp_tjetty,
                                 int *send_idx, int *target_idx, const bondp_chip_id_info_t *info)
{
    uint32_t min_active_count = MIN(bdp_comp->active_count, bdp_tjetty->active_count);
    bondp_path_t least_load_path[URMA_UBAGG_MAX_CONNECTION] = {{0, 0}};
    uint32_t least_load_cnt = 0;
    bool enable_info_fallback = true;
    int ret;
    uint32_t min[2] = { 0 };
    uint32_t max[2] = { 0 };

    if (min_active_count == 0) {
        URMA_LOG_ERR("Invalid min_active_count.\n");
        return URMA_EINVAL;
    }

    if (info != NULL) {
        ret = get_affinity_path_range(bdp_comp, info, min, max);
        if (ret != 0) {
            return ret;
        }
        select_least_load_path(bdp_comp, bdp_tjetty, min, max, least_load_path, &least_load_cnt);
        if (least_load_cnt == 0 && !enable_info_fallback) {
            return URMA_FAIL;
        }
    }

    if (least_load_cnt == 0) {
        if (bdp_comp->bondp_ctx->bonding_level == BONDP_BONDING_LEVEL_IODIE) {
            min[0] = min[1] = 0;
            max[0] = max[1] = IODIE_NUM;
        } else if (bdp_comp->bondp_ctx->bonding_level == BONDP_BONDING_LEVEL_PORT) {
            min[0] = min[1]  = IODIE_NUM;
            max[0] = max[1] = URMA_UBAGG_DEV_MAX_NUM;
        } else {
            URMA_LOG_ERR("Unsupported bonding level=%d.\n", bdp_comp->bondp_ctx->bonding_level);
            return URMA_EINVAL;
        }
        select_least_load_path(bdp_comp, bdp_tjetty, min, max, least_load_path, &least_load_cnt);
    }

    if (least_load_cnt == 0) {
        return URMA_FAIL;
    }

    uint32_t selected_pos = select_random_path(least_load_cnt);
    *send_idx = least_load_path[selected_pos].local_idx;
    *target_idx = least_load_path[selected_pos].target_idx;
    return 0;
}

static int schedule_recv_standalone(const bondp_comp_t *bdp_comp, int *recv_idx)
{
    *recv_idx = (int)bdp_comp->active_indices[0];
    return 0;
}

static int schedule_recv_balance(const bondp_comp_t *bdp_comp, int *recv_idx)
{
    int least_load_idx = -1;
    uint32_t least_load = UINT32_MAX;

    for (uint32_t i = 0; i < bdp_comp->active_count; i++) {
        uint32_t active_idx = bdp_comp->active_indices[i];
        uint32_t rqe_cnt = bdp_comp->rqe_cnt[active_idx];
        if (rqe_cnt < least_load) {
            least_load = rqe_cnt;
            least_load_idx = (int)active_idx;
        }
    }

    if (least_load_idx < 0) {
        return -1;
    }

    *recv_idx = least_load_idx;
    return 0;
}

int schedule_send(urma_target_jetty_t *tjetty, bondp_comp_t *bdp_comp, int *send_idx, int *target_idx,
                  bondp_chip_id_info_t *info)
{
    bondp_target_jetty_t *bdp_tjetty = CONTAINER_OF_FIELD(tjetty, bondp_target_jetty_t, v_tjetty);
    if (bdp_tjetty == NULL) {
        URMA_LOG_ERR("Invalid wr->tjetty: NULL\n");
        return URMA_EINVAL;
    }

    if (bdp_comp->active_count == 0 || bdp_tjetty->active_count == 0) {
        URMA_LOG_ERR("No active port\n");
        return -1;
    }

    switch (bdp_comp->bondp_ctx->bonding_mode) {
        case BONDP_BONDING_MODE_STANDALONE:
            return schedule_send_standalone(bdp_comp, bdp_tjetty, send_idx, target_idx);
        case BONDP_BONDING_MODE_ACTIVE_BACKUP:
            return schedule_send_active_backup(bdp_comp, bdp_tjetty, send_idx, target_idx);
        case BONDP_BONDING_MODE_BALANCE:
            return schedule_send_balance(bdp_comp, bdp_tjetty, send_idx, target_idx, info);
        default:
            return -1;
    }
}

int schedule_recv(bondp_comp_t *bdp_comp, int *recv_idx)
{
    if (bdp_comp->active_count == 0) {
        URMA_LOG_ERR("No active port\n");
        return -1;
    }

    switch (bdp_comp->bondp_ctx->bonding_mode) {
        case BONDP_BONDING_MODE_STANDALONE:
            return schedule_recv_standalone(bdp_comp, recv_idx);
        case BONDP_BONDING_MODE_ACTIVE_BACKUP:
        case BONDP_BONDING_MODE_BALANCE:
            return schedule_recv_balance(bdp_comp, recv_idx);
        default:
            return -1;
    }
}

int schedule_recv_n(bondp_comp_t *bdp_comp, uint32_t wr_num, uint32_t recv_wr_cnt[URMA_UBAGG_DEV_MAX_NUM])
{
    uint32_t current_load[URMA_UBAGG_DEV_MAX_NUM] = {0};

    if (recv_wr_cnt == NULL) {
        URMA_LOG_ERR("Invalid recv_wr_cnt: NULL\n");
        return URMA_EINVAL;
    }

    if (bdp_comp->active_count == 0) {
        URMA_LOG_ERR("No active port\n");
        return -1;
    }

    (void)memset(recv_wr_cnt, 0, sizeof(uint32_t) * URMA_UBAGG_DEV_MAX_NUM);
    if (wr_num == 0) {
        return 0;
    }

    for (uint32_t i = 0; i < bdp_comp->active_count; i++) {
        uint32_t active_idx = bdp_comp->active_indices[i];
        current_load[active_idx] = bdp_comp->rqe_cnt[active_idx];
    }

    for (uint32_t wr_idx = 0; wr_idx < wr_num; wr_idx++) {
        int least_load_idx = -1;
        uint32_t least_load = UINT32_MAX;

        for (uint32_t i = 0; i < bdp_comp->active_count; i++) {
            uint32_t active_idx = bdp_comp->active_indices[i];
            if (current_load[active_idx] < least_load) {
                least_load = current_load[active_idx];
                least_load_idx = (int)active_idx;
            }
        }

        if (least_load_idx < 0) {
            return -1;
        }

        recv_wr_cnt[least_load_idx]++;
        current_load[least_load_idx]++;
    }

    return 0;
}
